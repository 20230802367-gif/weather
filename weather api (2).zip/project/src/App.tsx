import React from 'react';
import { QueryClient, QueryClientProvider } from 'react-query';
import WeatherDashboard from './components/WeatherDashboard';

// Create a client
const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WeatherDashboard />
    </QueryClientProvider>
  );
}

export default App;