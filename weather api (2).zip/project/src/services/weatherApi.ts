import axios from 'axios';
import { WeatherData } from '../types/weather';

const API_KEY = '84f21fa104284723b9a153207250506';
const BASE_URL = 'https://api.weatherapi.com/v1';

export async function fetchWeatherData(location: string): Promise<WeatherData> {
  try {
    const response = await axios.get(`${BASE_URL}/forecast.json`, {
      params: {
        key: API_KEY,
        q: location,
        days: 5,
        aqi: 'yes',
        alerts: 'no',
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching weather data:', error);
    throw error;
  }
}

export async function searchLocations(query: string): Promise<any[]> {
  if (!query || query.length < 3) return [];
  
  try {
    const response = await axios.get(`${BASE_URL}/search.json`, {
      params: {
        key: API_KEY,
        q: query,
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error searching locations:', error);
    return [];
  }
}