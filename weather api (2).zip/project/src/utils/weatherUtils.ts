export function getWeatherBackground(code: number, isDay: boolean = true) {
  // Weather condition codes from WeatherAPI.com
  // Group them by weather type to determine background
  
  // Clear/Sunny (1000)
  if (code === 1000) {
    return isDay 
      ? 'bg-gradient-to-br from-blue-400 to-blue-600' 
      : 'bg-gradient-to-br from-blue-900 to-indigo-900';
  }
  
  // Partly cloudy (1003)
  if (code === 1003) {
    return isDay
      ? 'bg-gradient-to-br from-blue-300 to-blue-500'
      : 'bg-gradient-to-br from-slate-800 to-blue-900';
  }
  
  // Cloudy (1006, 1009)
  if (code === 1006 || code === 1009) {
    return isDay
      ? 'bg-gradient-to-br from-gray-300 to-blue-400'
      : 'bg-gradient-to-br from-gray-800 to-slate-900';
  }
  
  // Mist/Fog (1030, 1135, 1147)
  if ([1030, 1135, 1147].includes(code)) {
    return isDay
      ? 'bg-gradient-to-br from-gray-300 to-gray-400'
      : 'bg-gradient-to-br from-gray-700 to-gray-900';
  }
  
  // Rain (1063, 1150, 1153, 1180, 1183, 1186, 1189, 1192, 1195, 1240, 1243, 1246)
  if ([1063, 1150, 1153, 1180, 1183, 1186, 1189, 1192, 1195, 1240, 1243, 1246].includes(code)) {
    return isDay
      ? 'bg-gradient-to-br from-gray-400 to-blue-500'
      : 'bg-gradient-to-br from-gray-800 to-blue-800';
  }
  
  // Snow (1066, 1114, 1117, 1210, 1213, 1216, 1219, 1222, 1225, 1255, 1258)
  if ([1066, 1114, 1117, 1210, 1213, 1216, 1219, 1222, 1225, 1255, 1258].includes(code)) {
    return isDay
      ? 'bg-gradient-to-br from-blue-100 to-blue-300'
      : 'bg-gradient-to-br from-blue-900 to-slate-900';
  }
  
  // Thunderstorms (1087, 1273, 1276, 1279, 1282)
  if ([1087, 1273, 1276, 1279, 1282].includes(code)) {
    return isDay
      ? 'bg-gradient-to-br from-gray-600 to-blue-700'
      : 'bg-gradient-to-br from-gray-900 to-purple-900';
  }
  
  // Default for any other condition
  return isDay
    ? 'bg-gradient-to-br from-blue-300 to-blue-500'
    : 'bg-gradient-to-br from-slate-800 to-blue-900';
}

// Convert temperature for display with units
export function formatTemperature(temp: number, unit: string) {
  return `${Math.round(temp)}${unit}`;
}

// Format time from API
export function formatTime(timeString: string) {
  const date = new Date(timeString);
  return date.toLocaleTimeString('en-US', { 
    hour: 'numeric', 
    minute: '2-digit',
    hour12: true 
  });
}

// Get time of day (day or night) based on local time
export function isDay(localTime: string) {
  const date = new Date(localTime);
  const hours = date.getHours();
  return hours >= 6 && hours < 20; // Assume day is between 6am and 8pm
}