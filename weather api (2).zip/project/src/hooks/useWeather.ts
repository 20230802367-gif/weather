import { useQuery } from 'react-query';
import { fetchWeatherData, searchLocations } from '../services/weatherApi';
import { WeatherData, TemperatureUnit } from '../types/weather';
import { useState } from 'react';

export function useWeather() {
  const [location, setLocation] = useState<string>('London');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [unit, setUnit] = useState<TemperatureUnit>('celsius');

  const { 
    data: weatherData, 
    isLoading: isWeatherLoading, 
    error: weatherError,
    refetch: refetchWeather
  } = useQuery<WeatherData, Error>(
    ['weather', location],
    () => fetchWeatherData(location),
    {
      enabled: !!location,
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 30, // 30 minutes
    }
  );

  const { 
    data: locationSuggestions = [], 
    isLoading: isLocationsLoading 
  } = useQuery(
    ['locations', searchQuery],
    () => searchLocations(searchQuery),
    {
      enabled: searchQuery.length >= 3,
      staleTime: 1000 * 60 * 10, // 10 minutes
    }
  );

  const toggleTemperatureUnit = () => {
    setUnit(unit === 'celsius' ? 'fahrenheit' : 'celsius');
  };

  const handleLocationSelect = (newLocation: string) => {
    setLocation(newLocation);
    setSearchQuery('');
  };

  const handleSearchChange = (query: string) => {
    setSearchQuery(query);
  };

  return {
    weatherData,
    isWeatherLoading,
    weatherError,
    locationSuggestions,
    isLocationsLoading,
    unit,
    searchQuery,
    location,
    refetchWeather,
    toggleTemperatureUnit,
    handleLocationSelect,
    handleSearchChange,
  };
}