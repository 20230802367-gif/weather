import React from 'react';
import { useWeather } from '../hooks/useWeather';
import SearchBar from './SearchBar';
import CurrentWeather from './CurrentWeather';
import WeatherForecast from './WeatherForecast';
import HourlyForecast from './HourlyForecast';
import { getWeatherBackground, isDay } from '../utils/weatherUtils';
import { Cloud, CloudDrizzle, CloudLightning, CloudSnow, Loader2 } from 'lucide-react';

export default function WeatherDashboard() {
  const {
    weatherData,
    isWeatherLoading,
    weatherError,
    locationSuggestions,
    isLocationsLoading,
    unit,
    searchQuery,
    toggleTemperatureUnit,
    handleLocationSelect,
    handleSearchChange,
  } = useWeather();

  if (isWeatherLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-blue-100 to-blue-200 p-4">
        <div className="flex items-center gap-3 text-blue-600">
          <Loader2 className="w-8 h-8 animate-spin" />
          <span className="text-xl font-medium">Loading weather data...</span>
        </div>
      </div>
    );
  }

  if (weatherError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-red-100 to-red-200 p-4">
        <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full text-center">
          <CloudDrizzle className="w-16 h-16 mx-auto text-red-500 mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Oops! Something went wrong</h2>
          <p className="text-gray-600 mb-4">We couldn't fetch the weather data. Please try again later.</p>
          <p className="text-red-600 text-sm">Error: {weatherError.message}</p>
        </div>
      </div>
    );
  }

  if (!weatherData) {
    return null;
  }

  // Determine if it's day or night at the location
  const isDayTime = isDay(weatherData.location.localtime);
  
  // Get weather-based background
  const bgColor = getWeatherBackground(weatherData.current.condition.code, isDayTime);

  return (
    <div className={`min-h-screen ${bgColor} transition-colors duration-700`}>
      <div className="container mx-auto p-4 sm:p-6 md:p-8">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-white text-center mb-6 drop-shadow-sm">
            Weather Dashboard
          </h1>
          <SearchBar
            searchQuery={searchQuery}
            onSearchChange={handleSearchChange}
            locationSuggestions={locationSuggestions}
            isLoading={isLocationsLoading}
            onLocationSelect={handleLocationSelect}
          />
        </header>

        <main className="max-w-5xl mx-auto">
          <CurrentWeather 
            weatherData={weatherData} 
            unit={unit} 
            onUnitToggle={toggleTemperatureUnit} 
          />
          
          <HourlyForecast weatherData={weatherData} unit={unit} />
          
          <WeatherForecast weatherData={weatherData} unit={unit} />
        </main>

        <footer className="mt-12 text-center text-white text-sm opacity-75">
          <p>Weather data provided by WeatherAPI.com</p>
        </footer>
      </div>
    </div>
  );
}