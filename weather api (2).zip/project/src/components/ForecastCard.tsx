import React from 'react';
import { ForecastDay, TemperatureUnit } from '../types/weather';

interface ForecastCardProps {
  forecast: ForecastDay;
  unit: TemperatureUnit;
  isToday: boolean;
}

export default function ForecastCard({ forecast, unit, isToday }: ForecastCardProps) {
  const date = new Date(forecast.date);
  const dayName = isToday 
    ? 'Today' 
    : date.toLocaleDateString('en-US', { weekday: 'short' });
  
  const formattedDate = date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  });

  // Temperature based on selected unit
  const maxTemp = unit === 'celsius' 
    ? Math.round(forecast.day.maxtemp_c) 
    : Math.round(forecast.day.maxtemp_f);
  
  const minTemp = unit === 'celsius' 
    ? Math.round(forecast.day.mintemp_c) 
    : Math.round(forecast.day.mintemp_f);
  
  const tempUnit = unit === 'celsius' ? '°C' : '°F';

  // Rain/snow probability
  const precipType = forecast.day.daily_will_it_rain ? 'rain' : forecast.day.daily_will_it_snow ? 'snow' : null;
  const precipChance = precipType === 'rain' 
    ? forecast.day.daily_chance_of_rain 
    : precipType === 'snow' 
      ? forecast.day.daily_chance_of_snow 
      : 0;

  return (
    <div className={`bg-white rounded-lg shadow-md p-4 transition-all duration-300 hover:shadow-lg
      ${isToday ? 'border-l-4 border-blue-500' : ''}`}>
      <div className="flex flex-col items-center">
        <div className="font-medium text-lg mb-1">{dayName}</div>
        <div className="text-sm text-gray-500 mb-3">{formattedDate}</div>
        
        <img 
          src={forecast.day.condition.icon} 
          alt={forecast.day.condition.text} 
          className="w-16 h-16 object-contain mb-2" 
        />
        
        <div className="text-sm font-medium mb-3">{forecast.day.condition.text}</div>
        
        <div className="flex items-center justify-between w-full">
          <span className="text-blue-600 font-medium">{maxTemp}{tempUnit}</span>
          <span className="text-gray-500">{minTemp}{tempUnit}</span>
        </div>
        
        {precipType && (
          <div className="mt-2 text-sm text-gray-600">
            {precipChance}% chance of {precipType}
          </div>
        )}
        
        <div className="mt-3 text-xs text-gray-500 flex justify-between w-full">
          <div>
            <div>☀️ {forecast.astro.sunrise}</div>
            <div>🌙 {forecast.astro.sunset}</div>
          </div>
          <div className="text-right">
            <div>UV: {forecast.day.uv}</div>
            <div>{forecast.day.avgtemp_c}°C avg</div>
          </div>
        </div>
      </div>
    </div>
  );
}