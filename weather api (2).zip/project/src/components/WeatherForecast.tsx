import React from 'react';
import { WeatherData, TemperatureUnit } from '../types/weather';
import ForecastCard from './ForecastCard';

interface WeatherForecastProps {
  weatherData: WeatherData;
  unit: TemperatureUnit;
}

export default function WeatherForecast({ weatherData, unit }: WeatherForecastProps) {
  const today = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD

  return (
    <div className="mb-8">
      <h2 className="text-xl font-bold text-gray-800 mb-4">5-Day Forecast</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {weatherData.forecast.forecastday.map((forecast, index) => (
          <ForecastCard 
            key={forecast.date} 
            forecast={forecast} 
            unit={unit} 
            isToday={forecast.date === today}
          />
        ))}
      </div>
    </div>
  );
}