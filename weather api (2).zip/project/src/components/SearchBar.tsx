import React, { useState, useRef, useEffect } from 'react';
import { Search } from 'lucide-react';

interface Location {
  id: number;
  name: string;
  region: string;
  country: string;
}

interface SearchBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  locationSuggestions: Location[];
  isLoading: boolean;
  onLocationSelect: (location: string) => void;
}

export default function SearchBar({
  searchQuery,
  onSearchChange,
  locationSuggestions,
  isLoading,
  onLocationSelect,
}: SearchBarProps) {
  const [isFocused, setIsFocused] = useState(false);
  const suggestionsRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        suggestionsRef.current && 
        !suggestionsRef.current.contains(event.target as Node) &&
        inputRef.current &&
        !inputRef.current.contains(event.target as Node)
      ) {
        setIsFocused(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleSuggestionClick = (suggestion: Location) => {
    onLocationSelect(suggestion.name);
    setIsFocused(false);
  };

  return (
    <div className="relative w-full max-w-md mx-auto mb-6">
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          onFocus={() => setIsFocused(true)}
          placeholder="Search location..."
          className="w-full py-3 pl-10 pr-4 text-gray-700 bg-white rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
        />
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <Search className="w-5 h-5 text-gray-500" />
        </div>
      </div>

      {isFocused && searchQuery.length >= 3 && (
        <div 
          ref={suggestionsRef}
          className="absolute z-10 w-full mt-2 bg-white rounded-lg shadow-lg overflow-hidden transition-all"
        >
          {isLoading ? (
            <div className="p-4 text-center text-gray-500">Loading...</div>
          ) : locationSuggestions.length > 0 ? (
            <ul>
              {locationSuggestions.map((suggestion) => (
                <li 
                  key={suggestion.id}
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="px-4 py-3 hover:bg-gray-100 cursor-pointer transition-colors"
                >
                  <div className="font-medium">{suggestion.name}</div>
                  <div className="text-sm text-gray-600">
                    {suggestion.region}, {suggestion.country}
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="p-4 text-center text-gray-500">No locations found</div>
          )}
        </div>
      )}
    </div>
  );
}