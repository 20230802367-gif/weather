import React from 'react';
import { ThermometerSun, Droplets, Wind, Sun, CloudRain } from 'lucide-react';
import { WeatherData, TemperatureUnit } from '../types/weather';

interface CurrentWeatherProps {
  weatherData: WeatherData;
  unit: TemperatureUnit;
  onUnitToggle: () => void;
}

export default function CurrentWeather({ 
  weatherData, 
  unit, 
  onUnitToggle 
}: CurrentWeatherProps) {
  const { location, current } = weatherData;
  const date = new Date(location.localtime);
  const formattedDate = date.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const formattedTime = date.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });

  // Format temperature based on selected unit
  const temp = unit === 'celsius' ? current.temp_c : current.temp_f;
  const feelsLike = unit === 'celsius' ? current.feelslike_c : current.feelslike_f;
  const tempUnit = unit === 'celsius' ? '°C' : '°F';

  // Air quality index levels
  const getAirQualityLabel = (index: number) => {
    const labels = ['Good', 'Moderate', 'Unhealthy for Sensitive Groups', 'Unhealthy', 'Very Unhealthy', 'Hazardous'];
    return labels[index - 1] || 'Unknown';
  };

  const getAirQualityColor = (index: number) => {
    const colors = ['text-green-600', 'text-yellow-600', 'text-orange-500', 'text-red-500', 'text-purple-600', 'text-rose-700'];
    return colors[index - 1] || 'text-gray-600';
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-6 transition-all duration-300 hover:shadow-xl">
      <div className="p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">{location.name}</h2>
            <p className="text-gray-600">{location.country}</p>
            <p className="text-sm text-gray-500">{formattedDate} • {formattedTime}</p>
          </div>
          <button 
            onClick={onUnitToggle}
            className="mt-2 sm:mt-0 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium hover:bg-blue-200 transition-colors self-start"
          >
            Switch to {unit === 'celsius' ? '°F' : '°C'}
          </button>
        </div>

        <div className="flex flex-col md:flex-row items-center md:items-start">
          <div className="flex items-center md:mr-8">
            <img 
              src={current.condition.icon} 
              alt={current.condition.text} 
              className="w-24 h-24 object-contain"
            />
            <div className="ml-2">
              <div className="text-5xl font-bold text-gray-800">{Math.round(temp)}{tempUnit}</div>
              <div className="text-gray-600">Feels like {Math.round(feelsLike)}{tempUnit}</div>
            </div>
          </div>
          
          <div className="mt-4 md:mt-0 text-center md:text-left">
            <div className="text-xl font-medium text-gray-800">{current.condition.text}</div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
              <div className="flex flex-col items-center md:items-start">
                <div className="flex items-center text-gray-600">
                  <Droplets className="w-4 h-4 mr-1" />
                  <span>Humidity</span>
                </div>
                <span className="text-lg font-medium">{current.humidity}%</span>
              </div>
              
              <div className="flex flex-col items-center md:items-start">
                <div className="flex items-center text-gray-600">
                  <Wind className="w-4 h-4 mr-1" />
                  <span>Wind</span>
                </div>
                <span className="text-lg font-medium">
                  {unit === 'celsius' ? `${current.wind_kph} km/h` : `${current.wind_mph} mph`}
                </span>
              </div>
              
              <div className="flex flex-col items-center md:items-start">
                <div className="flex items-center text-gray-600">
                  <CloudRain className="w-4 h-4 mr-1" />
                  <span>Precipitation</span>
                </div>
                <span className="text-lg font-medium">{current.precip_mm} mm</span>
              </div>
              
              <div className="flex flex-col items-center md:items-start">
                <div className="flex items-center text-gray-600">
                  <Sun className="w-4 h-4 mr-1" />
                  <span>UV Index</span>
                </div>
                <span className="text-lg font-medium">{current.uv}</span>
              </div>
            </div>
          </div>
        </div>

        {current.air_quality && (
          <div className="mt-6 p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Air Quality:</span>
              <span className={`font-medium ${getAirQualityColor(current.air_quality["us-epa-index"])}`}>
                {getAirQualityLabel(current.air_quality["us-epa-index"])}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}