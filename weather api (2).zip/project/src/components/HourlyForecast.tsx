import React, { useState, useRef, useEffect } from 'react';
import { WeatherData, TemperatureUnit, HourForecast } from '../types/weather';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface HourlyForecastProps {
  weatherData: WeatherData;
  unit: TemperatureUnit;
}

export default function HourlyForecast({ weatherData, unit }: HourlyForecastProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  // Get today's hourly forecast
  const todayForecast = weatherData.forecast.forecastday[0];
  const currentHour = new Date().getHours();
  
  // Filter to show only future hours for today
  const filteredHours = todayForecast.hour.filter(hour => {
    const hourTime = new Date(hour.time);
    return hourTime.getHours() >= currentHour;
  });

  // If not enough hours left today, add some from tomorrow
  let hourlyData = [...filteredHours];
  if (hourlyData.length < 12 && weatherData.forecast.forecastday.length > 1) {
    const tomorrowHours = weatherData.forecast.forecastday[1].hour;
    const neededHours = 12 - hourlyData.length;
    hourlyData = [...hourlyData, ...tomorrowHours.slice(0, neededHours)];
  }

  const checkScrollPosition = () => {
    if (!scrollRef.current) return;
    
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    setCanScrollLeft(scrollLeft > 0);
    setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
  };

  useEffect(() => {
    const scrollContainer = scrollRef.current;
    if (scrollContainer) {
      scrollContainer.addEventListener('scroll', checkScrollPosition);
      // Initial check
      checkScrollPosition();
      
      return () => {
        scrollContainer.removeEventListener('scroll', checkScrollPosition);
      };
    }
  }, [weatherData]);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { clientWidth } = scrollRef.current;
      const scrollAmount = clientWidth * 0.8;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const formatHourLabel = (time: string) => {
    const date = new Date(time);
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric',
      hour12: true 
    });
  };

  const formatDay = (time: string) => {
    const date = new Date(time);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    if (date.toDateString() === today.toDateString()) return 'Today';
    if (date.toDateString() === tomorrow.toDateString()) return 'Tomorrow';
    
    return date.toLocaleDateString('en-US', { weekday: 'short' });
  };

  return (
    <div className="mb-8">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Hourly Forecast</h2>
      
      <div className="relative">
        {canScrollLeft && (
          <button 
            onClick={() => scroll('left')}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 rounded-full p-1 shadow-md hover:bg-white transition-colors"
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>
        )}
        
        <div 
          ref={scrollRef}
          className="flex overflow-x-auto pb-4 scrollbar-hide hide-scrollbar" 
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {hourlyData.map((hour, index) => (
            <div 
              key={hour.time_epoch} 
              className="flex-none w-24 px-2"
            >
              <div className="bg-white rounded-lg shadow-sm p-3 text-center h-full">
                <div className="text-xs font-medium text-gray-500 mb-1">
                  {formatDay(hour.time)}
                </div>
                <div className="text-sm font-semibold mb-2">
                  {formatHourLabel(hour.time)}
                </div>
                <img 
                  src={hour.condition.icon} 
                  alt={hour.condition.text}
                  className="w-10 h-10 mx-auto mb-2"
                />
                <div className="text-base font-medium">
                  {unit === 'celsius' ? 
                    `${Math.round(hour.temp_c)}°C` : 
                    `${Math.round(hour.temp_f)}°F`
                  }
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {hour.chance_of_rain > 0 && `${hour.chance_of_rain}% 💧`}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {canScrollRight && (
          <button 
            onClick={() => scroll('right')}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 rounded-full p-1 shadow-md hover:bg-white transition-colors"
            aria-label="Scroll right"
          >
            <ChevronRight className="w-6 h-6 text-gray-700" />
          </button>
        )}
      </div>
    </div>
  );
}